package com.example.anggotaperpus

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// DATA CLASS (SAMA KAYAK BUKU, ISI AJA YANG BEDA)
data class ListItem(
    val id_anggota: Int,
    val nama: String,
    val email: String,
    val foto: String
)

class MainActivity : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var listAdapter: ListAdapter
    private lateinit var searchEditText: EditText

    private val allItems = ArrayList<ListItem>()
    private var filteredItems = ArrayList<ListItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        listView = findViewById(R.id.listview)
        searchEditText = findViewById(R.id.searchEditText)

        listAdapter = ListAdapter(this, filteredItems)
        listView.adapter = listAdapter

        fetchAnggotaFromAPI()

        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterList(s.toString())
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun fetchAnggotaFromAPI() {
        Thread {
            try {
                val url = URL("http://192.168.100.88/perpustakaan-uts/api/anggota.php") // ganti IP kalau perlu
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "GET"
                conn.connect()

                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                val dataArray = json.getJSONArray("data")

                val tempList = ArrayList<ListItem>()

                for (i in 0 until dataArray.length()) {
                    val o = dataArray.getJSONObject(i)
                    tempList.add(
                        ListItem(
                            id_anggota = o.getInt("id_anggota"),
                            nama = o.getString("nama_lengkap"),
                            email = o.getString("email"),
                            foto = o.getString("foto")
                        )
                    )
                }

                runOnUiThread {
                    allItems.clear()
                    allItems.addAll(tempList)

                    filteredItems.clear()
                    filteredItems.addAll(tempList)

                    listAdapter.updateList(filteredItems)
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
    }

    private fun filterList(query: String) {
        val result = if (query.isEmpty()) {
            allItems
        } else {
            allItems.filter {
                it.nama.contains(query, true) ||
                        it.email.contains(query, true)
            }
        }

        filteredItems = ArrayList(result)
        listAdapter.updateList(filteredItems)
    }
}
