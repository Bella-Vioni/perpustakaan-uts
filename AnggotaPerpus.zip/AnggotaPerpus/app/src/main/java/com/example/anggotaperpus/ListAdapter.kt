package com.example.anggotaperpus

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide

class ListAdapter(
    private val context: Context,
    private var items: MutableList<ListItem>
) : BaseAdapter() {

    override fun getCount(): Int = items.size

    override fun getItem(position: Int): Any = items[position]

    override fun getItemId(position: Int): Long =
        items[position].id_anggota.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View
        val holder: ViewHolder

        if (convertView == null) {
            view = LayoutInflater.from(context)
                .inflate(R.layout.items_list, parent, false)

            holder = ViewHolder()
            holder.titleTextView = view.findViewById(R.id.titleTextView)
            holder.authorTextView = view.findViewById(R.id.authorTextView)
            holder.coverImageView = view.findViewById(R.id.coverImageView)

            view.tag = holder
        } else {
            view = convertView
            holder = view.tag as ViewHolder
        }

        val item = items[position]

        holder.titleTextView?.text = item.nama
        holder.authorTextView?.text = item.email

        Glide.with(context)
            .load(item.foto)
            .placeholder(android.R.drawable.ic_menu_report_image)
            .into(holder.coverImageView!!)

        return view
    }

    fun updateList(newItems: MutableList<ListItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    private class ViewHolder {
        var titleTextView: TextView? = null
        var authorTextView: TextView? = null
        var coverImageView: ImageView? = null
    }
}
